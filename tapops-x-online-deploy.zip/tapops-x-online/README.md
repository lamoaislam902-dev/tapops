# TAPOPS X v4.0 — Online starter

## What is included
- `public/index.html`: single-file frontend
- `server.js`: Express API + Socket.IO signaling
- SQLite database created automatically in `database/`
- Password hashing and JWT authentication

## Run locally
1. Install Node.js 20 or newer.
2. Copy `.env.example` to `.env`.
3. Set `JWT_SECRET` to a long random secret (32+ characters).
4. Run `npm install`
5. Run `npm start`
6. Open `http://localhost:3000`

## Deploy
Deploy this whole project folder to a Node.js host that supports persistent disk/storage and WebSockets.
Set environment variable `JWT_SECRET` in the host dashboard. Set `CLIENT_ORIGIN` to the deployed site origin if you want to restrict browser origins.
The host must provide persistent storage for the SQLite file in `database/`; otherwise the database may reset when the service restarts or redeploys. For production, use a managed database and configure a TURN server for reliable WebRTC calls.

## Important
- Do not share `.env` or your JWT secret.
- Browser microphone access requires HTTPS (localhost is the exception).
- STUN-only WebRTC may fail on some networks; configure TURN for reliable calls.
- This is a starter project, not a security-audited production service.
