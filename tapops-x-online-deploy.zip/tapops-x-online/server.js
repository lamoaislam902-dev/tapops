require("dotenv").config();
const express = require("express");
const http = require("http");
const path = require("path");
const fs = require("fs");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Database = require("better-sqlite3");
const { Server } = require("socket.io");

const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET || JWT_SECRET.length < 32) {
  console.error("Set JWT_SECRET to a random secret of at least 32 characters.");
  process.exit(1);
}

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: process.env.CLIENT_ORIGIN || true } });
app.use(express.json({ limit: "20kb" }));
app.use(express.static(path.join(__dirname, "public")));

const dbDir = path.join(__dirname, "database");
fs.mkdirSync(dbDir, { recursive: true });
const db = new Database(path.join(dbDir, "tapops.db"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 email TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL,
 agent_id TEXT NOT NULL UNIQUE,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

const online = new Map(); // agentId -> socketId
const sockets = new Map(); // socketId -> user
const makeToken = user => jwt.sign({ id: user.id, agentId: user.agent_id }, JWT_SECRET, { expiresIn: "7d" });
const publicUser = user => ({ id: user.id, name: user.name, email: user.email, agentId: user.agent_id });

function auth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    const user = db.prepare("SELECT id,name,email,agent_id FROM users WHERE id=?").get(payload.id);
    if (!user) return res.status(401).json({ error: "Account not found" });
    req.user = user; next();
  } catch { return res.status(401).json({ error: "Invalid or expired token" }); }
}
function makeAgentId() {
  let id;
  do { id = "TX-" + Math.random().toString(36).slice(2, 8).toUpperCase(); }
  while (db.prepare("SELECT 1 FROM users WHERE agent_id=?").get(id));
  return id;
}
app.get("/api/health", (_req,res) => res.json({ ok:true, service:"TAPOPS X API", version:"4.0.0" }));
app.post("/api/register", (req,res) => {
  try {
    const name = String(req.body.name || "").trim().slice(0,32);
    const email = String(req.body.email || "").trim().toLowerCase();
    const password = String(req.body.password || "");
    if (name.length < 2) return res.status(400).json({ error:"Name must be at least 2 characters" });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error:"Enter a valid email" });
    if (password.length < 8 || password.length > 72) return res.status(400).json({ error:"Password must be 8–72 characters" });
    const agentId = makeAgentId();
    const info = db.prepare("INSERT INTO users (name,email,password_hash,agent_id) VALUES (?,?,?,?)")
      .run(name,email,bcrypt.hashSync(password,12),agentId);
    const user = db.prepare("SELECT id,name,email,agent_id FROM users WHERE id=?").get(info.lastInsertRowid);
    return res.status(201).json({ token:makeToken(user), user:publicUser(user) });
  } catch (e) {
    if (String(e.message).includes("UNIQUE")) return res.status(409).json({ error:"Email already registered" });
    console.error(e); return res.status(500).json({ error:"Registration failed" });
  }
});
app.post("/api/login", (req,res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  const user = db.prepare("SELECT * FROM users WHERE email=?").get(email);
  if (!user || !bcrypt.compareSync(password,user.password_hash)) return res.status(401).json({ error:"Incorrect email or password" });
  res.json({ token:makeToken(user), user:publicUser(user) });
});
app.get("/api/me", auth, (req,res) => res.json(publicUser(req.user)));
app.get("/api/agents", auth, (_req,res) => {
  const users = db.prepare("SELECT id,name,agent_id FROM users ORDER BY name COLLATE NOCASE").all();
  res.json(users.map(u => ({ id:u.id, name:u.name, agentId:u.agent_id, online:online.has(u.agent_id) })));
});

io.use((socket,next) => {
  try {
    const token = socket.handshake.auth && socket.handshake.auth.token;
    const payload = jwt.verify(token,JWT_SECRET);
    const user = db.prepare("SELECT id,name,email,agent_id FROM users WHERE id=?").get(payload.id);
    if (!user) return next(new Error("Unauthorized"));
    socket.user = user; next();
  } catch { next(new Error("Unauthorized")); }
});
function sendToAgent(agentId,event,payload={}) {
  const socketId = online.get(agentId);
  if (socketId) io.to(socketId).emit(event,{ ...payload, from: payload.from });
}
io.on("connection", socket => {
  const user = socket.user;
  online.set(user.agent_id,socket.id);
  sockets.set(socket.id,user);
  io.emit("agent:status",{ agentId:user.agent_id, online:true });

  socket.on("call:invite", ({to}={}) => {
    const target = online.get(String(to || ""));
    if (target) io.to(target).emit("call:incoming",{ from:user.agent_id, fromName:user.name });
    else socket.emit("call:rejected",{ reason:"Agent is offline" });
  });
  socket.on("call:accept", ({to}={}) => {
    const target = online.get(String(to || ""));
    if (target) io.to(target).emit("call:accepted",{ from:user.agent_id });
  });
  socket.on("call:reject", ({to}={}) => {
    const target = online.get(String(to || ""));
    if (target) io.to(target).emit("call:rejected",{ from:user.agent_id });
  });
  socket.on("call:end", ({to}={}) => {
    const target = online.get(String(to || ""));
    if (target) io.to(target).emit("call:ended",{ from:user.agent_id });
  });
  for (const event of ["webrtc:offer","webrtc:answer","webrtc:ice"]) {
    socket.on(event, data => {
      if (!data || typeof data.to !== "string") return;
      const target = online.get(data.to);
      if (!target) return;
      const payload = { ...data, from:user.agent_id, fromName:user.name };
      delete payload.to;
      io.to(target).emit(event,payload);
    });
  }
  socket.on("disconnect", () => {
    sockets.delete(socket.id);
    if (online.get(user.agent_id) === socket.id) {
      online.delete(user.agent_id);
      io.emit("agent:status",{ agentId:user.agent_id, online:false });
    }
  });
});

app.get("*", (req,res,next) => {
  if (req.path.startsWith("/api/")) return next();
  res.sendFile(path.join(__dirname,"public","index.html"));
});
app.use((err,_req,res,_next) => {
  console.error(err); res.status(500).json({ error:"Internal server error" });
});
server.listen(PORT,"0.0.0.0",() => console.log(`TAPOPS X listening on ${PORT}`));
